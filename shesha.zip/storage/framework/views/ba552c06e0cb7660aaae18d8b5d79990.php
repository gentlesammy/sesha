


<?php $__env->startSection("title", "Shisha: Start Sharing Secrets"); ?>


<?php $__env->startSection("hero_section"); ?>
    <h1> START SHARING SHI  </h1>
    <P>Pour out all your heart out, like no one is watching, <br> <small>Remember we listen, we dont judge</small></P>
    <a href="#" class="btn btn-primary">Read <i class="fa-brands fa-readme"></i></a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-md-8">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('create-secret', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-82223789-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

        <div class="col-md-4">
            <div class="px-3">
                <ul class="list-group">
                    <li class="list-group-item pry-bg alt-text" aria-current="true">Remember Our Rules</li>
                    <li class="list-group-item">No mentioning of names</li>
                    <li class="list-group-item">No description of someone</li>
                    <li class="list-group-item">We reserve the right to delete any content</li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.shisha", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/shisha_frontend/create.blade.php ENDPATH**/ ?>