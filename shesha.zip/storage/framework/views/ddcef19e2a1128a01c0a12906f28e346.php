<div class="col-md-8">
    <div class="mb-4">
        <form wire:submit.prevent>
            <div class="p-3" style="background-color: #fff;box-shadow: 0 8px 10px rgba(2, 8, 34, 0.3), 0 16px 40px rgba(2, 8, 34, 0.25); border-radius: 8px; display: flex; align-items: center;">
            
            <input type="text" class="form-control me-2" placeholder="Search..." wire:model.lazy="searchTerm" placeholder="Search by title or content">
            
            <select class="form-select me-2" style="max-width: 200px;" wire:model="selectedCategory">
                    <option value="">All Categories</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            
            <button class="btn btn-primary me-2" wire:click="$refresh">Search</button>
            <button class="btn btn-danger"  wire:click="resetFilters">Reset</button>
            </div>
        </form>
    </div>
    <!-- all shi -->
    <div wire:loading.delay class="fixed top-0 left-0 right-0 bg-blue-500 text-white py-2 text-center">
        Loading results...
    </div>
    <!--[if BLOCK]><![endif]--><?php if($secrets->count()): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $secrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if (isset($component)) { $__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e = $attributes; } ?>
<?php $component = App\View\Components\SingleSecret::resolve(['secret' => $secret] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-secret'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSecret::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e)): ?>
<?php $attributes = $__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e; ?>
<?php unset($__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e)): ?>
<?php $component = $__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e; ?>
<?php unset($__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e); ?>
<?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($secrets->links()); ?>

        </div>
    <?php else: ?>
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6 text-center">
                <p class="text-gray-500">No secrets found matching your search criteria.</p>
                <button class="btn btn-danger"  wire:click="resetFilters">Clear Search</button>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
   

    
</div>
<?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/livewire/secret-timeline.blade.php ENDPATH**/ ?>