




<?php $__env->startSection("content"); ?>
        <div class="row vh-50 pt-5">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2"> Secrets Shared</p>
                        <h6 class="mb-0"><?php echo e($secrets); ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-bar fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Categories</p>
                        <h6 class="mb-0"><?php echo e($categories); ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-area fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Tags</p>
                        <h6 class="mb-0"><?php echo e($tags); ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-pie fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Views</p>
                        <h6 class="mb-0"><?php echo e($views); ?></h6>
                    </div>
                </div>
            </div>
        </div>

        <div class="row vh-50 pt-5" style="height: 50vh;">
            <div class="col-md-6">

                <form action="<?php echo e(route('admin.categories.recalculate')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label class="form-label"> Due to secrets expiring, do this once a day</label>
                    <button type="submit" class="btn btn-primary">Recalculate Category Secret Count</button>
                </form>
            </div>

        </div>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_dash", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>