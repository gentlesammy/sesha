


<?php $__env->startSection("content"); ?>
    <h1> <?php echo e($secret->title); ?> </h1>
    <p> Category: <strong><?php echo e($secret->category->title); ?></strong>  </p>
    <p> Summary: <strong><?php echo e($secret->summary); ?></strong>  </p>
    <br>
    <?php if(session("success")): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong> <span class="fa fa-check"> &nbsp; </span> Success! </strong> <?php echo e(session("success")); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>
    
    <?php if($secret->expires_at && $secret->expires_at->isPast()): ?>
        <form action="/admin/secrets/<?php echo e($secret->id); ?>}/update" method="post" class="bg-white shadow-sm p-3 mb-5 rounded">
            <h3 class="text-center text-primary my-3"> Secret Expired <strong>But You can extend it</strong></h3>
            <hr>
            <?php echo csrf_field(); ?>
            <?php echo method_field("patch"); ?>
            <div class="row mb-3 p-3">
                <div class="col-md-6">
                   <label for="expires_at" class="mb-3">Set New Expiration Date</label> 
                </div>
                
                <div class="col-md-6">
                    <select class="form-select border-0" id="Lifecycle" name="lifecycle"  wire:model='lifecycle'>
                        <option value="" selected>How long should your shi be available</option>
                        <?php $__currentLoopData = $expirationOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                        <?php $__errorArgs = ["lifecycle"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                
            </div>
            <button type="submit" class="btn btn-primary">Extend Secret Lifecycle</button>
        </form>
    <?php endif; ?>
    <hr>
    <p> <?php echo e($secret->content); ?> </p>
    <p> <?php echo e($secret->created_at); ?> </p>

    <hr/>
    <h3> Manage Tag for this secret </h3>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('secret-tag-manager', ['secret' => $secret]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2709174671-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
   <?php $__env->startPush('scripts'); ?>
        <script>
        document.addEventListener('livewire:load', function() {
            // Focus input after tag is added
            Livewire.on('tag-added', () => {
                document.querySelector('[wire\\:model="tagInput"]').focus();
            });
            
            // Handle keyboard navigation for Enter key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && e.target.getAttribute('wire:model') === 'tagInput') {
                    Livewire.emit('selectHighlighted');
                }
            });
        });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/admin/secrets/show.blade.php ENDPATH**/ ?>