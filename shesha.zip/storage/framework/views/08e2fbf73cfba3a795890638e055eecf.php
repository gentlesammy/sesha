<!-- resources/views/livewire/secret-tag-manager.blade.php -->
<div class="secret-tags-container mb-4">
    <label class="form-label">Tags</label>
    
    <!-- Current Tags Display -->
    <div class="d-flex flex-wrap gap-2 mb-3" wire:ignore>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge bg-primary d-flex align-items-center py-2 pe-1">
                <?php echo e($name); ?>

                <button 
                    wire:click="removeTag(<?php echo e($id); ?>)" 
                    class="btn-close btn-close-white ms-2"
                    style="font-size: 0.5rem;"
                    aria-label="Remove tag"
                ></button>
            </span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    
    <!-- Tag Input with Suggestions -->
    <div class="position-relative">
        <div class="input-group">
            <input
                type="text"
                wire:model="tagInput"
                wire:keydown.enter.prevent="addNewTag"
                wire:keydown.arrow-up.prevent="highlightPrevious"
                wire:keydown.arrow-down.prevent="highlightNext"
                wire:keydown.escape="$set('suggestions', [])"
                placeholder="Type to add tags..."
                class="form-control <?php $__errorArgs = ['tagInput'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                aria-label="Add tags"
                wire:loading.attr="disabled"
                wire:target="addNewTag,selectTag"
            >
            <button 
                wire:click="addNewTag"
                class="btn btn-outline-secondary"
                type="button"
                wire:loading.attr="disabled"
                wire:target="addNewTag"
            >
                <span wire:loading.remove wire:target="addNewTag">Add</span>
                <span wire:loading wire:target="addNewTag" class="spinner-border spinner-border-sm"></span>
            </button>
        </div>
        
        <!-- Suggestions Dropdown -->
        <!--[if BLOCK]><![endif]--><?php if(count($suggestions) > 0): ?>
            <div class="list-group position-absolute w-100 mt-1 shadow" style="z-index: 1000; max-height: 200px; overflow-y: auto;">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button
                        type="button"
                        wire:click="selectTag(<?php echo e($id); ?>, '<?php echo e($name); ?>')"
                        class="list-group-item list-group-item-action text-start <?php echo e($highlightIndex === $loop->index ? 'active' : ''); ?>"
                    >
                        <?php echo e($name); ?>

                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    
    <!-- Error Message -->
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tagInput'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback d-block">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    
    <!-- Help Text -->
    <small class="form-text text-muted">
        Type to search existing tags or create new ones. Press Enter to add.
    </small>
</div>

<?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/livewire/secret-tag-manager.blade.php ENDPATH**/ ?>