<div class="card">
    <div class="card-header bg-primary text-white">
        <h2 class="h5 mb-0">You can manage Secrets Here</h2>
    </div>
    <div class="card-body">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row g-3">
                    <!-- Search Input -->
                    <div class="col-md-8">
                        <input 
                            type="text" 
                            wire:model="search" 
                            placeholder="Search by title or content..." 
                            class="form-control"
                        >
                    </div>
    
                    <!-- Category Filter -->
                    <div class="col-md-4">
                        <select wire:model="categoryId" class="form-select">
                            <option value="">All Categories</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
    
                    <!-- Status Filters -->
                    <div class="col-6 col-sm-4">
                        <select wire:model="isBlocked" class="form-select">
                            <option value="">All Status</option>
                            <option value="1">Blocked Only</option>
                            <option value="0">Active Only</option>
                        </select>
                    </div>
    
                    <div class="col-6 col-sm-4">
                        <select wire:model="isEditorChoice" class="form-select">
                            <option value="">All</option>
                            <option value="1">Editor's Choice</option>
                            <option value="0">Not Editor's Choice</option>
                        </select>
                    </div>
                    <!-- Group By IP -->
                    <div class="col-6 col-sm-4">
                        <div class="form-check form-switch">
                            <input 
                                wire:model="groupByIp" 
                                class="form-check-input" 
                                type="checkbox" 
                                id="groupByIp"
                            >
                            <label class="form-check-label" for="groupByIp">Group by IP</label>
                        </div>
                    </div>
                    
                    <div class="col-md-6 d-flex gap-2">
                        <button 
                            wire:click="applyFilters"
                            wire:loading.attr="disabled"
                            class="btn btn-outline-secondary flex-grow-1"
                        >
                            <span wire:loading.remove>
                                <i class="fas fa-search mr-1"></i> Search
                            </span>
                            <span wire:loading>
                                <i class="fas fa-spinner fa-spin mr-1"></i> 
                            </span>
                        </button>
                        <button 
                            wire:click="clearFilters"
                            wire:loading.attr="disabled"
                            class="btn btn-outline-secondary"
                            title="Clear all filters"
                        >
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <!--[if BLOCK]><![endif]--><?php if($filtersApplied): ?>
                        <div class="mt-3 text-muted small">
                            Filters applied. <a href="#" wire:click="clearFilters" class="text-primary">Clear all</a>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead class="bg-primary text-white">
                    <tr>
                        <th wire:click="sortBy('title')" style="cursor: pointer;">
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'title'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            Title
                        </th>
                        <th wire:click="sortBy('category_id')" style="cursor: pointer;">
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'category_id'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            Category 
                        </th>
                        <th wire:click="sortBy('ip_address')" style="cursor: pointer;">
                            
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'ip_address'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            IP Address 
                        </th>
                        <th wire:click="sortBy('upvotes')" style="cursor: pointer;">
                            
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'upvotes'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <i class="fa fa-thumbs-up" title="upvotes"></i> 
                        </th>
                        <th wire:click="sortBy('downvotes')" style="cursor: pointer;">
                            
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'downvotes'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            
                            <i class="fa fa-thumbs-down" title="downvotes"></i>
                        </th>
                        <th wire:click="sortBy('views')" style="cursor: pointer;">
                            
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'views'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <i class="fa fa-eye" title="views"></i>
                        </th>
                        <th wire:click="sortBy('created_at')" style="cursor: pointer;">
                            
                            <!--[if BLOCK]><![endif]--><?php if($sortField === 'created_at'): ?> <?php echo $__env->make('partials.sort-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            Date  Created   
                        </th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php if($groupByIp): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $secrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ipGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="6">
                                    <strong>IP: <?php echo e($ipGroup->ip_address); ?></strong> 
                                    (<?php echo e($ipGroup->secret_count); ?> secrets)
                                </td>
                                <td colspan="3">
                                    <button 
                                        wire:click="$set('groupByIp', false)"
                                        class="btn btn-sm btn-outline-secondary"
                                    >
                                        View Secrets
                                    </button>
                                </td>
                    
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $secrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="500"><?php echo e(Str::limit($secret->title, 30)); ?></td>
                                <td><?php echo e($secret->category->title); ?></td>
                                <td><?php echo e($secret->ip_address); ?></td>
                                <td><?php echo e($secret->upvotes); ?></td>
                                <td><?php echo e($secret->downvotes); ?></td>
                                <td><?php echo e($secret->views); ?></td>
                                <td>
                                    <?php echo e($secret->created_at->format('M d, Y')); ?>

                                    <!--[if BLOCK]><![endif]--><?php if($secret->expires_at && $secret->expires_at->isPast()): ?>
                                        <span class="badge bg-danger">Expired</span>
                                    <?php elseif($secret->expires_at): ?>
                                        <span class="badge bg-warning text-dark">
                                            Expires: <?php echo e($secret->expires_at->diffForHumans()); ?>

                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($secret->is_blocked): ?>
                                        <span class="badge bg-danger">Blocked</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    
                                    <!--[if BLOCK]><![endif]--><?php if($secret->is_editor_choice): ?>
                                        <span class="badge bg-primary mt-1"> Choice</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <!--[if BLOCK]><![endif]--><?php if($secret->is_blocked): ?>
                                            <button 
                                                wire:click="unblockSecret(<?php echo e($secret->id); ?>)"
                                                class="btn btn-sm btn-success"
                                                title="Unblock"
                                            >
                                            <i class="fas fa-ban text-white"></i>
                                            </button>
                                        <?php else: ?>
                                            <button 
                                                wire:click="blockSecret(<?php echo e($secret->id); ?>)"
                                                class="btn btn-sm btn-warning"
                                                title="Block"
                                            >
                                            <i class="fas fa-eye-slash"></i>
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        
                                        <button 
                                            wire:click="expireSecret(<?php echo e($secret->id); ?>)"
                                            class="btn btn-sm btn-info"
                                            title="Expire Now"
                                        >
                                            <i class="bi bi-clock-history"></i>
                                        </button>
                                        
                                        <button 
                                            wire:click="toggleEditorChoice(<?php echo e($secret->id); ?>)"
                                            class="btn btn-sm <?php echo e($secret->is_editor_choice ? 'btn-primary' : 'btn-outline-primary'); ?>"
                                            title="<?php echo e($secret->is_editor_choice ? 'Remove from Editor\'s Choice' : 'Mark as Editor\'s Choice'); ?>"
                                        >
                                            <i class="bi bi-star"></i>
                                        </button>
                                        
                                        <button 
                                            wire:click="deleteSecret(<?php echo e($secret->id); ?>)"
                                            class="btn btn-sm btn-danger"
                                            title="Delete"
                                            onclick="return confirm('Are you sure?')"
                                        >
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <a href="secrets/<?php echo e($secret->id); ?>/show" class="btn btn-sm btn-secondary" title="View Secret">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            <?php echo e($secrets->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/livewire/admin-manage-secret.blade.php ENDPATH**/ ?>