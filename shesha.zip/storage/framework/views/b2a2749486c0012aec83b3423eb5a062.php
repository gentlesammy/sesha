

<?php $__env->startSection("hero_section"); ?>
    <h1> SHARED SESHAS </h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
<div class="row">

    <!-- main:  timeline section -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('secret-timeline', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3782049000-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <!-- sidebar -->
    <div class="col-md-4">
            <div class="row">
                <div class="col text-center  mb-4 pt-3">
                    <h4>  Shi Category </h4>
                </div>
            </div>

            <div class="row">
                <div class="col">
                   <?php if (isset($component)) { $__componentOriginal8daf9a954c8f412042664b6b343f77c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8daf9a954c8f412042664b6b343f77c0 = $attributes; } ?>
<?php $component = App\View\Components\Category::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Category::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8daf9a954c8f412042664b6b343f77c0)): ?>
<?php $attributes = $__attributesOriginal8daf9a954c8f412042664b6b343f77c0; ?>
<?php unset($__attributesOriginal8daf9a954c8f412042664b6b343f77c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8daf9a954c8f412042664b6b343f77c0)): ?>
<?php $component = $__componentOriginal8daf9a954c8f412042664b6b343f77c0; ?>
<?php unset($__componentOriginal8daf9a954c8f412042664b6b343f77c0); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col text-center   mb-4 pt-3">
                    <h4> Popular  Secrets </h4>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="shi-cat-box">
                        <?php if (isset($component)) { $__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61 = $attributes; } ?>
<?php $component = App\View\Components\PopularSecrets::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('popular-secrets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PopularSecrets::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61)): ?>
<?php $attributes = $__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61; ?>
<?php unset($__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61)): ?>
<?php $component = $__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61; ?>
<?php unset($__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.shisha", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/shisha_frontend/timeline.blade.php ENDPATH**/ ?>