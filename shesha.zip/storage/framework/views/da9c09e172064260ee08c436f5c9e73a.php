


<?php $__env->startSection("page_name", "Login"); ?>


<?php $__env->startSection("content"); ?>
    <form action="/login" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-floating mb-3">
            <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="email">
            <label for="floatingInput">Email address</label>
            <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="alert alert-danger">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-floating mb-4">
            <input type="password" class="form-control" id="mypassword" placeholder="Password" name="password">
            <label for="mypassword">Password</label>
            <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="alert alert-danger">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="passtoggle" name="remember">
                <label class="form-check-label" for="passtoggle" id='toggle_label'>show Password</label>
            </div>
            <a href="<?php echo e(route('password.request')); ?>">Forgot Password</a>
        </div>
        <button type="submit" class="btn btn-primary py-3 w-100 mb-4">Sign In</button>
        <p class="text-center mb-0">Don't have an Account? <a href="<?php echo e(route('register')); ?>">Sign Up</a></p>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
    <script>
        $(document).ready(function() {
            //when passtoggle is clicked, toggle the type of the password input and 
            $("#passtoggle").click(function() {
                if ($(this).is(":checked")) {
                    $("#mypassword").attr("type", "text");
                    $("#toggle_label").text("hide Password");
                } else {
                    $("#mypassword").attr("type", "password");
                    $("#toggle_label").text("show Password");
                }
            });
        });
    </script>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/shi_auth/login.blade.php ENDPATH**/ ?>