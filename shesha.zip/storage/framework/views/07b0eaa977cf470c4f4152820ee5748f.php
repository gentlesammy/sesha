

<?php $__env->startSection("content"); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title text-secondary">Profile Picture</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <form action="<?php echo e(route('admin.profile.updatePicture')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-group my-3">
                                <label for="picture">Upload New Profile Picture</label>
                                <input type="file" class="form-control mt-2" id="picture" name="picture" accept="image/*">
                                <?php $__errorArgs = ['picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Profile Picture</button>
                        </form>
                    </div>
                    <div class="col-md-6">
                         <p class="text-muted">Current Profile Picture:</p>
                           <?php if(auth()->user()->display_picture): ?>
                           <img src="<?php echo e(asset('storage/' . auth()->user()->display_picture)); ?>" alt="Profile Picture" class="img-thumbnail" style="max-width: 150px;"> 
                            <?php else: ?>
                            <img class="rounded-circle" src="/admin/img/user.jpg" alt="" style="max-width: 150px;">
                            
                            <?php endif; ?>
                        
                    </div>
                </div>
                


            </div>
            
        </div>        
</div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_dash", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Pictures\shesha\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>